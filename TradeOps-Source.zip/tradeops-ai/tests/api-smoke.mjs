import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const base=process.argv[2]||'http://127.0.0.1:8787';let cookie='';let checks=0;
async function req(body,extra={}){const r=await fetch(`${base}/api/deals`,{method:body?'POST':'GET',headers:{...(body?{'Content-Type':'application/json'}:{}),...(cookie?{Cookie:cookie}:{}),...extra},...(body?{body:JSON.stringify(body)}:{})});if(r.headers.get('set-cookie'))cookie=r.headers.get('set-cookie').split(';')[0];const text=await r.text();if(!text)throw new Error(`Empty HTTP response ${r.status} from ${base}: ${JSON.stringify([...r.headers])}`);return {status:r.status,data:JSON.parse(text)};}
function verify(value,message){assert.ok(value,message);checks++;console.log(`PASS ${message}`);}
const initial=await req();verify(initial.status===200&&initial.data.deals.length>=3,'Seeded deals are served from database');
const body={operation:'create',id:crypto.randomUUID(),goal:'Оплатить 380000 CNY',contract:readFileSync('samples/contract.txt','utf8'),invoice:readFileSync('samples/invoice.txt','utf8')};
let result=await req(body),deal=result.data.deal;verify(result.status===201&&deal.state==='draft','Create persists real document text');
const command=(action,version=deal.version,key=crypto.randomUUID())=>({operation:'action',id:deal.id,version,commandId:key,action});
result=await req(command({type:'submit'}));verify(result.status===422,'Cannot bypass confirmation through direct API');
result=await req(command({type:'analyze'}));deal=result.data.deal;verify(result.status===200&&deal.state==='ready','Server extracts and validates fields');
result=await req(command({type:'approve',confirmed:true},1));verify(result.status===409,'Stale versions are rejected');
result=await req(command({type:'approve',confirmed:true}));deal=result.data.deal;verify(result.status===200&&deal.state==='approved','Explicit confirmation recorded');
const send=command({type:'submit'});result=await req(send);deal=result.data.deal;verify(result.status===200&&deal.state==='submitted','Payment simulator executes');
result=await req(send);verify(result.status===200&&result.data.deal.version===deal.version,'Retry is idempotent');
result=await req(command({type:'reconcile',received:'378500',correspondentFee:'1500',senderFee:'250',currency:'CNY'}));deal=result.data.deal;verify(deal.state==='exception'&&deal.exception.differenceMinor===150000,'Shortfall creates structured exception');
result=await req(command({type:'escalate'}));deal=result.data.deal;verify(deal.state==='escalated'&&deal.exception.ticket,'Case is added to demo queue');
result=await req();verify(result.data.deals.some(d=>d.id===deal.id&&d.state==='escalated'),'State survives a new GET');
const ownCookie=cookie;cookie='';await req();result=await req(command({type:'analyze'}));verify(result.status===404,'Another session cannot mutate the deal');cookie=ownCookie;
result=await req(command({type:'analyze'}),{Origin:'https://untrusted.example'});verify(result.status===403,'Cross-origin mutation rejected');
const fresh=await req({...body,id:crypto.randomUUID()});deal=fresh.data.deal;deal=(await req(command({type:'analyze'}))).data.deal;
const concurrent=await Promise.all([req(command({type:'approve',confirmed:true})),req(command({type:'approve',confirmed:true}))]);verify(concurrent.map(r=>r.status).sort().join(',')==='200,409','Concurrent updates cannot overwrite each other');
console.log(`\n${checks} HTTP checks passed. Uses synthetic data only.`);
export {cookie};
