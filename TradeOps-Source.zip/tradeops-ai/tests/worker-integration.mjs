import {createRequire} from 'node:module';
import {readFileSync,rmSync,mkdirSync,readdirSync} from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
const wranglerRequire=createRequire(import.meta.resolve('wrangler/package.json'));
const {Miniflare}=wranglerRequire('miniflare');
const persist=path.resolve('.test-dist/integration-d1');
rmSync(persist,{recursive:true,force:true});mkdirSync(persist,{recursive:true});
const options={name:'tradeops-test',modules:[{type:'ESModule',path:path.resolve('dist/server/index.js')},...readdirSync('dist/server',{recursive:true}).filter(f=>/\.m?js$/.test(f)&&f!=='index.js').map(f=>({type:'ESModule',path:path.resolve('dist/server',f)}))],modulesRoot:path.resolve('dist/server'),modulesRules:[{type:'ESModule',include:['**/*.js','**/*.mjs']}],compatibilityDate:'2026-05-15',compatibilityFlags:['nodejs_compat'],d1Databases:{DB:'tradeops-test'},d1Persist:persist,cf:false};
let mf=new Miniflare(options);
try {
 const db=await mf.getD1Database('DB');
 for(const sql of readFileSync('drizzle/0000_cynical_tempest.sql','utf8').split('--> statement-breakpoint').filter(s=>s.trim()))await db.exec(sql.replace(/\n/g,' '));
 globalThis.fetch=(url,init)=>mf.dispatchFetch(String(url),init);
 process.argv[2]='http://tradeops.test';
 const suite=await import('./api-smoke.mjs');
 const home=await mf.dispatchFetch('http://tradeops.test/');
 assert.equal(home.status,200);assert.match(await home.text(),/TradeOps/);console.log('PASS Production Worker renders root HTML');
 await mf.dispose();mf=new Miniflare(options);
 const reload=await mf.dispatchFetch('http://tradeops.test/api/deals',{headers:{Cookie:suite.cookie}});
 const data=await reload.json();assert.ok(data.deals.some(d=>d.state==='escalated'));console.log('PASS Database survives Worker restart');
} finally {await mf.dispose();}
