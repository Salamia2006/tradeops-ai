import { sqliteTable, text, integer, index, primaryKey } from 'drizzle-orm/sqlite-core';
export const sessions = sqliteTable('demo_sessions', {
  owner: text('owner').primaryKey(), createdAt: text('created_at').notNull()
});
export const deals = sqliteTable('deals', {
  id: text('id').notNull(), owner: text('owner').notNull(), version: integer('version').notNull(),
  data: text('data').notNull(), updatedAt: text('updated_at').notNull()
}, t => [primaryKey({columns:[t.owner,t.id]}),index('idx_deals_owner_updated').on(t.owner,t.updatedAt)]);
