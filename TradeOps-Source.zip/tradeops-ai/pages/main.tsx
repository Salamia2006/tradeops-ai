import React, { Component, type ErrorInfo, type ReactNode } from 'react';
import { createRoot } from 'react-dom/client';
import Home from '../app/page';
import '../app/globals.css';

class ErrorBoundary extends Component<{children: ReactNode}, {error: boolean}> {
  state = { error: false };
  static getDerivedStateFromError() { return { error: true }; }
  componentDidCatch(error: Error, info: ErrorInfo) { console.error('TradeOps UI', error, info.componentStack); }
  render() {
    if (this.state.error) return <main style={{maxWidth:620,margin:'60px auto',padding:24}}><h1>Не удалось открыть демо</h1><p style={{margin:'20px 0'}}>Обновите страницу в современном браузере. Если ошибка повторяется, сохранённые ранее данные остаются в локальном хранилище.</p><button className="button primary" onClick={()=>location.reload()}>Обновить страницу</button></main>;
    return this.props.children;
  }
}

createRoot(document.getElementById('root')!).render(<React.StrictMode><ErrorBoundary><Home/></ErrorBoundary></React.StrictMode>);
