import { transitionWorkspace, type BrowserWorkspace } from '../lib/tradeops/browser-store';
import type { ApiResponse } from '../lib/tradeops/client';

export const storageMode: 'server' | 'browser' = 'browser';
const databaseName = 'tradeops-ai-pages-v1';
let connection: Promise<IDBDatabase> | undefined;

function openDatabase(): Promise<IDBDatabase> {
  if (!globalThis.indexedDB) return Promise.reject(new Error('Браузер не разрешает локальное хранилище. Откройте демо в обычном режиме браузера.'));
  if (!connection) connection = new Promise<IDBDatabase>((resolve, reject) => {
    const request = indexedDB.open(databaseName, 1);
    request.onupgradeneeded = () => { request.result.createObjectStore('workspace'); };
    request.onsuccess = () => {
      const db = request.result;
      db.onversionchange = () => { db.close(); connection = undefined; };
      resolve(db);
    };
    request.onerror = () => { connection = undefined; reject(new Error('Не удалось открыть локальное хранилище. Проверьте настройки браузера.')); };
    request.onblocked = () => { connection = undefined; reject(new Error('Закройте старые вкладки демо и обновите страницу.')); };
  });
  return connection;
}

export async function api(body?: unknown): Promise<ApiResponse> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    // A single read-write transaction serializes edits even across tabs.
    const transaction = db.transaction('workspace', 'readwrite');
    const store = transaction.objectStore('workspace');
    const request = store.get('current');
    let result: ApiResponse;
    let domainError: Error | undefined;
    request.onsuccess = () => {
      try {
        const next = transitionWorkspace(request.result as BrowserWorkspace | undefined, body);
        result = next.response;
        if (!request.result || body !== undefined) store.put(next.workspace, 'current');
      } catch (error) { domainError = error as Error; transaction.abort(); }
    };
    transaction.oncomplete = () => resolve(result);
    transaction.onabort = () => reject(domainError || new Error('Изменения не сохранены. Возможно, хранилище браузера заполнено или недоступно.'));
    transaction.onerror = () => { /* onabort reports failure and prevents optimistic success. */ };
  });
}
