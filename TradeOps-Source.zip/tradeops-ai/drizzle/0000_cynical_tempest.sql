CREATE TABLE `deals` (
	`id` text NOT NULL,
	`owner` text NOT NULL,
	`version` integer NOT NULL,
	`data` text NOT NULL,
	`updated_at` text NOT NULL,
	PRIMARY KEY(`owner`, `id`)
);
--> statement-breakpoint
CREATE INDEX `idx_deals_owner_updated` ON `deals` (`owner`,`updated_at`);--> statement-breakpoint
CREATE TABLE `demo_sessions` (
	`owner` text PRIMARY KEY NOT NULL,
	`created_at` text NOT NULL
);
