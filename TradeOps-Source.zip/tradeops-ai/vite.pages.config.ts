import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'node:path';

const project = import.meta.dirname;
export default defineConfig({
  root: path.join(project, 'pages'),
  base: './',
  publicDir: path.join(project, 'public'),
  plugins: [react()],
  resolve: { alias: [
    { find: '@/lib/tradeops/client', replacement: path.join(project, 'pages/local-api.ts') },
    { find: '@', replacement: project }
  ] },
  css: { postcss: project },
  build: {
    outDir: path.join(project, 'docs'),
    emptyOutDir: false,
    sourcemap: false,
    target: 'es2022',
    chunkSizeWarningLimit: 800
  }
});
