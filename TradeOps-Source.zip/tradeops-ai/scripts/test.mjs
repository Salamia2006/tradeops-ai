import ts from 'typescript';
import {mkdirSync,writeFileSync,readFileSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
mkdirSync('.test-dist',{recursive:true});
writeFileSync('.test-dist/package.json','{"type":"commonjs"}');
for(const name of ['types','adapters','engine','fixtures','browser-store']) {
 const source=readFileSync(`lib/tradeops/${name}.ts`,'utf8');
 const result=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}});
 writeFileSync(`.test-dist/${name}.js`,result.outputText);
}
const result=spawnSync(process.execPath,['--test','tests/engine.test.cjs','tests/pages.test.cjs'],{stdio:'inherit'});
process.exit(result.status??1);
