import {spawnSync,spawn} from 'node:child_process';
import {existsSync,readdirSync,readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
const node=process.execPath;
function run(args){const result=spawnSync(node,args,{stdio:'inherit'});if(result.status!==0)process.exit(result.status??1);}
if(!existsSync('node_modules')){console.error('Сначала выполните pnpm install --frozen-lockfile (или npm install).');process.exit(1);}
console.log('TradeOps AI: сборка локального демо…');
run(['scripts/run-framework.mjs','build']);
mkdirSync('.wrangler',{recursive:true});
const markerPath='.wrangler/tradeops-local-migrations.json';
const applied=existsSync(markerPath)?JSON.parse(readFileSync(markerPath,'utf8')):{};
for(const file of readdirSync('drizzle').filter(f=>f.endsWith('.sql')).sort()) {
 const hash=createHash('sha256').update(readFileSync(`drizzle/${file}`)).digest('hex');
 if(applied[file]===hash)continue;
 if(applied[file])throw new Error(`Применённая миграция ${file} была изменена.`);
 run(['--import','./scripts/sites-env.mjs','./node_modules/wrangler/bin/wrangler.js','d1','execute','DB','--local','--config','dist/server/wrangler.json','--persist-to','.wrangler/state','--file',`drizzle/${file}`]);
 applied[file]=hash;writeFileSync(markerPath,JSON.stringify(applied,null,2));
}
console.log('\nОткройте http://127.0.0.1:8787 — сервер остаётся запущенным. Остановка: Ctrl+C.\n');
const child=spawn(node,['--import','./scripts/sites-env.mjs','./node_modules/wrangler/bin/wrangler.js','dev','--config','dist/server/wrangler.json','--local','--persist-to','.wrangler/state','--ip','127.0.0.1','--port','8787','--inspector-port','0'],{stdio:'inherit'});
process.on('SIGINT',()=>child.kill('SIGINT'));process.on('SIGTERM',()=>child.kill('SIGTERM'));child.on('exit',code=>process.exit(code??0));
