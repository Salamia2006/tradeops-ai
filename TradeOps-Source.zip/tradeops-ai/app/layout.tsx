import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "TradeOps AI — сопровождение ВЭД-сделок",
  description: "От документов до сверки расчётов. Демонстрационный MVP TradeOps AI.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ru">
      <body className="antialiased">{children}</body>
    </html>
  );
}
