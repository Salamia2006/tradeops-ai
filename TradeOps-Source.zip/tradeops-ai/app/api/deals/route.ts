import { createDeal, applyAction, DomainError } from '@/lib/tradeops/engine';
import { getDeal, initialize, insertDeal, listDeals, saveDeal } from '@/lib/tradeops/repository';
import { z } from 'zod';

export const dynamic = 'force-dynamic';
const documentFields = { goal:z.string().min(1).max(1000), contract:z.string().max(30000), invoice:z.string().max(30000) };
const actions = z.discriminatedUnion('type',[
  z.object({type:z.literal('analyze')}),z.object({type:z.literal('documents'),...documentFields}),
  z.object({type:z.literal('approve'),confirmed:z.boolean()}),z.object({type:z.literal('submit')}),
  z.object({type:z.literal('reconcile'),received:z.string().max(30),correspondentFee:z.string().max(30),senderFee:z.string().max(30),currency:z.string().length(3)}),
  z.object({type:z.literal('escalate')})
]);
function session(req: Request) {
  const user = req.headers.get('oai-authenticated-user-id');
  if (user) return { owner:`user:${user}`, cookie:undefined };
  const existing = req.headers.get('cookie')?.match(/(?:^|;\s*)tradeops_demo=([a-f0-9-]{36})(?:;|$)/)?.[1];
  const id = existing || crypto.randomUUID();
  return { owner:`demo:${id}`, cookie:existing ? undefined : `tradeops_demo=${id}; HttpOnly; SameSite=Strict; Path=/; Max-Age=604800${new URL(req.url).protocol === 'https:' ? '; Secure' : ''}` };
}
function response(value: unknown, status=200, cookie?:string) {
  return Response.json(value,{status,headers:{'Cache-Control':'no-store',...(cookie?{'Set-Cookie':cookie}:{})}});
}
function fail(error: unknown) {
  if (error instanceof z.ZodError) return response({error:'Некорректные поля запроса.',details:error.issues.map(i=>i.path.join('.'))},400);
  if (error instanceof DomainError) return response({error:error.message},422);
  console.error('TradeOps API failure',error instanceof Error ? error.message : 'Unknown');
  return response({error:'Не удалось сохранить или загрузить данные. Повторите попытку.'},503);
}
export async function GET(req: Request) {
  try { const s=session(req); await initialize(s.owner); return response({deals:await listDeals(s.owner),mode:'demo',engine:'rules-v1'},200,s.cookie); }
  catch(error){return fail(error);}
}
export async function POST(req: Request) {
  try {
    const origin = req.headers.get('origin');
    if (origin && new URL(origin).host !== new URL(req.url).host) return response({error:'Недопустимый источник запроса.'},403);
    if (!req.headers.get('content-type')?.includes('application/json')) return response({error:'Ожидается application/json.'},415);
    const raw = await req.text();
    if (new TextEncoder().encode(raw).length > 180000) return response({error:'Слишком большой запрос.'},413);
    let body; try {body=JSON.parse(raw);} catch{return response({error:'Некорректный JSON.'},400);}
    const s = session(req); await initialize(s.owner);
    if (body.operation === 'create') {
      const data=z.object({operation:z.literal('create'),id:z.string().uuid(),...documentFields}).parse(body);
      const existing=await getDeal(s.owner,data.id);
      if(existing) return response({deal:existing},200,s.cookie);
      const d=createDeal(data.goal,data.contract,data.invoice,data.id);
      await insertDeal(s.owner,d); return response({deal:d},201,s.cookie);
    }
    const data=z.object({operation:z.literal('action'),id:z.string().uuid(),version:z.number().int().positive(),commandId:z.string().uuid(),action:actions}).parse(body);
    const current=await getDeal(s.owner,data.id);
    if(!current) return response({error:'Сделка не найдена.'},404,s.cookie);
    if(current.appliedCommands.includes(data.commandId)) return response({deal:current},200,s.cookie);
    if(current.version !== data.version) return response({error:'Сделка уже изменена. Обновите данные и повторите действие.'},409,s.cookie);
    const updated=applyAction(current,data.action,data.commandId);
    if(!await saveDeal(s.owner,updated,current.version)) return response({error:'Обнаружено параллельное изменение. Обновите данные.'},409,s.cookie);
    return response({deal:updated},200,s.cookie);
  } catch(error){return fail(error);}
}
