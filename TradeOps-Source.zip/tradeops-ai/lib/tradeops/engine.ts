import type { Action, Deal, DocumentRecord, DocKind, Check, PaymentDraft } from './types';
import { paymentGateway, currencyControlGateway, caseGateway } from './adapters';

export class DomainError extends Error { status = 422; }
export function moneyMinor(value: string): number {
  const raw = String(value).trim().replace(/[\s\u00a0\u202f]/g, '').replace(',', '.');
  if (!/^\d{1,10}(?:\.\d{1,2})?$/.test(raw)) throw new DomainError('Сумма должна быть неотрицательным числом с точностью до двух знаков.');
  const [whole, fraction = ''] = raw.split('.');
  return Number(whole) * 100 + Number(fraction.padEnd(2, '0'));
}
export const formatMoney = (minor: number, currency = 'CNY') => `${new Intl.NumberFormat('ru-RU', { minimumFractionDigits: minor % 100 ? 2 : 0, maximumFractionDigits: 2 }).format(minor / 100)} ${currency}`;
const labels: Record<string, string[]> = {
  contractId: ['контракт', 'номер контракта', 'contract'], invoiceId: ['инвойс', 'номер инвойса', 'invoice'],
  beneficiary: ['получатель', 'контрагент', 'beneficiary'], amount: ['сумма', 'amount'], currency: ['валюта', 'currency'],
  account: ['счёт', 'счет', 'account'], bankCode: ['код банка', 'swift', 'bic'], dueDate: ['срок оплаты', 'due date'],
  purpose: ['назначение', 'purpose'], charges: ['комиссии', 'charges'], country: ['страна', 'country']
};
export function extract(text: string, kind: DocKind): DocumentRecord {
  if (typeof text !== 'string' || text.length > 30000) throw new DomainError('Документ должен содержать не более 30 000 символов.');
  const result: DocumentRecord = { kind, name: kind === 'contract' ? 'contract.txt' : 'invoice.txt', text, fields: {}, evidence: {}, errors: [] };
  text.split(/\r?\n/).forEach((line, index) => {
    const match = line.match(/^\s*([^:]{1,40}):\s*(.*?)\s*$/);
    if (!match) return;
    const field = Object.keys(labels).find(key => labels[key].includes(match[1].toLowerCase()));
    if (!field || !match[2]) return;
    if (result.fields[field]) { result.errors.push(`Повторяющееся поле «${match[1]}», строка ${index + 1}.`); return; }
    result.fields[field] = match[2];
    result.evidence[field] = { line: index + 1, quote: line.trim() };
  });
  return result;
}
function addEvent(deal: Deal, title: string, detail: string, actor: 'Клиент' | 'Оркестратор' | 'Симулятор банка' = 'Оркестратор') {
  deal.audit.push({ id: crypto.randomUUID(), at: new Date().toISOString(), actor, title, detail });
}
export function createDeal(goal: string, contract: string, invoice: string, id = crypto.randomUUID()): Deal {
  if (!goal.trim() || goal.length > 1000) throw new DomainError('Опишите цель сделки: от 1 до 1 000 символов.');
  const at = new Date().toISOString();
  const documents = [extract(contract, 'contract'), extract(invoice, 'invoice')];
  const deal: Deal = { id, title: documents[0].fields.beneficiary || 'Новая сделка', goal, createdAt: at, updatedAt: at, version: 1, state: 'draft', documents, checks: [], audit: [], appliedCommands: [] };
  addEvent(deal, 'Создан контекст сделки', 'Цель и два текстовых документа сохранены. Все реквизиты используются только в демо.', 'Клиент');
  return deal;
}
function analyze(deal: Deal) {
  const contract = deal.documents.find(d => d.kind === 'contract')!;
  const invoice = deal.documents.find(d => d.kind === 'invoice')!;
  const checks: Check[] = [];
  const put = (id: string, ok: boolean, title: string, detail: string) => checks.push({ id, level: ok ? 'pass' : 'block', title, detail });
  for (const doc of [contract, invoice]) {
    const name = doc.kind === 'contract' ? 'Контракт' : 'Инвойс';
    const required = ['contractId','beneficiary','amount','currency','account','bankCode','dueDate','purpose','charges', ...(doc.kind === 'invoice' ? ['invoiceId'] : [])];
    const missing = required.filter(k => !doc.fields[k]);
    put(`${doc.kind}-fields`, missing.length === 0, `${name}: обязательные поля`, missing.length ? `Заполните: ${missing.map(k => labels[k][0]).join(', ')}.` : `Найдены ${required.length} обязательных полей; источник каждого поля сохранён.`);
    put(`${doc.kind}-ambiguity`, !doc.errors.length, `${name}: однозначность`, doc.errors.join(' ') || 'Повторяющихся полей нет.');
  }
  const a = contract.fields, b = invoice.fields;
  let amount = 0;
  try {
    amount = moneyMinor(b.amount || '');
    const ca = moneyMinor(a.amount || '');
    put('amount', amount > 0 && amount === ca, 'Сумма обязательства', amount === ca && amount > 0 ? 'Суммы совпадают. Демо поддерживает один инвойс на полную сумму контракта.' : `Контракт: ${a.amount || '—'}. Инвойс: ${b.amount || '—'}. Уточните документы.`);
  } catch { put('amount', false, 'Сумма обязательства', 'Не удалось однозначно прочитать сумму. Формат: 380000.00.'); }
  for (const field of ['contractId', 'beneficiary', 'currency', 'account', 'bankCode', 'charges', 'dueDate']) {
    const normalize = (v?: string) => (v || '').trim().replace(/\s+/g,' ').toUpperCase();
    put(`match-${field}`, !!a[field] && normalize(a[field]) === normalize(b[field]), `Сверка: ${labels[field][0]}`, `${a[field] || 'Не указано'} / ${b[field] || 'Не указано'}`);
  }
  put('currency', /^(CNY|USD|EUR|RUB|AED)$/.test(b.currency?.toUpperCase() || ''), 'Поддерживаемая валюта', 'В MVP: CNY, USD, EUR, RUB, AED. Обмен валют не выполняется.');
  put('bankCode', /^[A-Z]{6}[A-Z0-9]{2}([A-Z0-9]{3})?$/.test(b.bankCode || ''), 'Формат кода банка', 'Проверка длины и символов BIC; существование банка не проверяется.');
  put('account', /^[A-Z0-9-]{8,34}$/.test(b.account || ''), 'Формат счёта', 'Проверяется только формат, без обращения к реестрам.');
  put('charges', /^(OUR|SHA|BEN)$/.test(b.charges || ''), 'Распределение комиссий', 'Режим должен быть OUR, SHA или BEN; реальная тарификация определяется банком.');
  const date = b.dueDate || '';
  const dateOk = /^\d{4}-\d{2}-\d{2}$/.test(date) && !Number.isNaN(Date.parse(date)) && new Date(date).toISOString().slice(0,10) === date;
  put('date', dateOk, 'Срок оплаты', dateOk ? date : 'Нужна существующая дата в формате ГГГГ-ММ-ДД.');
  if (dateOk && date < new Date().toISOString().slice(0,10)) checks.push({ id:'past-due', level:'info',title:'Срок оплаты прошёл', detail:'Перед подтверждением уточните срок с контрагентом.' });
  const goalAmount = deal.goal.match(/(\d[\d \u00a0\u202f]*(?:[.,]\d{1,2})?)\s*(CNY|USD|EUR|RUB|AED)\b/i);
  if (goalAmount) {
    let match = false;
    try { match = moneyMinor(goalAmount[1]) === amount && goalAmount[2].toUpperCase() === b.currency?.toUpperCase(); } catch { /* blocked */ }
    put('goal', match, 'Соответствие цели клиента', `Цель: ${goalAmount[0]}; инвойс: ${b.amount || '—'} ${b.currency || ''}.`);
  } else checks.push({id:'goal',level:'info',title:'Цель требует прочтения клиентом',detail:'Сумма и валюта не извлечены из цели; проверьте черновик вручную.'});
  deal.checks = checks;
  deal.state = checks.some(c => c.level === 'block') ? 'needs_review' : 'ready';
  delete deal.approval;
  delete deal.payment;
  if (deal.state === 'ready') {
    deal.payment = { beneficiary:b.beneficiary, account:b.account, bankCode:b.bankCode, amountMinor:amount, currency:b.currency.toUpperCase(), purpose:b.purpose, charges:b.charges, contractId:b.contractId, invoiceId:b.invoiceId };
    const preflight = currencyControlGateway.preflight(deal.payment);
    deal.checks.push({ id:'bank-control', level:'info', title:'Валютный контроль: демо', detail:preflight.message });
  }
  addEvent(deal, 'Документы проанализированы', `${checks.filter(c => c.level === 'pass').length} проверок пройдено; ${checks.filter(c => c.level === 'block').length} блокирующих замечаний. Движок: rules-v1.`);
}
export function applyAction(original: Deal, action: Action, commandId: string): Deal {
  if (original.appliedCommands.includes(commandId)) return original;
  const deal = structuredClone(original);
  const requireState = (...states: Deal['state'][]) => { if (!states.includes(deal.state)) throw new DomainError(`Действие недоступно в статусе «${deal.state}».`); };
  switch(action.type) {
    case 'documents':
      requireState('draft','ready','needs_review','approved');
      if (!action.goal.trim() || action.goal.length > 1000) throw new DomainError('Укажите корректную цель сделки.');
      deal.goal = action.goal;
      deal.documents = [extract(action.contract,'contract'),extract(action.invoice,'invoice')];
      deal.title = deal.documents[0].fields.beneficiary || 'Новая сделка';
      deal.state = 'draft'; deal.checks = []; delete deal.payment; delete deal.approval;
      addEvent(deal,'Документы изменены','Предыдущее подтверждение сброшено. Нужны повторные проверки.', 'Клиент');
      break;
    case 'analyze': requireState('draft','ready','needs_review'); analyze(deal); break;
    case 'approve':
      requireState('ready');
      if (!action.confirmed || !deal.payment) throw new DomainError('Необходимо явное подтверждение платёжных данных.');
      deal.approval = { at:new Date().toISOString(), snapshot:structuredClone(deal.payment) };
      deal.state = 'approved';
      addEvent(deal,'Черновик подтверждён',`${formatMoney(deal.payment.amountMinor,deal.payment.currency)} · ${deal.payment.beneficiary}. Сохранён снимок реквизитов.`, 'Клиент');
      break;
    case 'submit': {
      requireState('approved');
      if (!deal.payment || !deal.approval || JSON.stringify(deal.payment) !== JSON.stringify(deal.approval.snapshot)) throw new DomainError('Реквизиты изменились. Подтвердите их повторно.');
      const sent = paymentGateway.submit(deal.payment, deal.id);
      deal.bankReference = sent.reference; deal.state = 'submitted';
      addEvent(deal,'Симуляция отправки завершена',`Референс: ${sent.reference}. Реальные деньги не отправлялись.`, 'Симулятор банка');
      break;
    }
    case 'reconcile': {
      requireState('submitted');
      const p = deal.payment!;
      if (action.currency !== p.currency) throw new DomainError('Валюта подтверждения должна совпадать с валютой платежа.');
      const receivedMinor = moneyMinor(action.received), correspondentFeeMinor = moneyMinor(action.correspondentFee), senderFeeMinor = moneyMinor(action.senderFee);
      deal.receipt = { receivedMinor, correspondentFeeMinor, senderFeeMinor, currency:action.currency, at:new Date().toISOString(), source:'demo' };
      const differenceMinor = p.amountMinor - receivedMinor;
      if (differenceMinor === 0) { deal.state = 'settled'; delete deal.exception; }
      else {
        const explained = differenceMinor > 0 && differenceMinor === correspondentFeeMinor;
        deal.state = 'exception';
        deal.exception = { id:`EX-${deal.id.slice(0,8).toUpperCase()}`, differenceMinor, feeExplainsDifference:explained,
          hypothesis: differenceMinor < 0 ? 'Полученная сумма превышает обязательство. Нужна сверка подтверждения зачисления.' : explained ? (p.charges === 'OUR' ? 'Разница равна указанной комиссии, но режим OUR требует отдельной проверки удержания. Причина не подтверждена банком.' : 'Разница совпадает с указанной комиссией корреспондента. Это вероятное объяснение, требующее банковского подтверждения.') : 'Указанные комиссии не объясняют расхождение полностью. Нужны дополнительные сведения о зачислении.',
          nextSteps:['Проверить подтверждение зачисления и удержанные комиссии.','Сверить условия контракта и распределение расходов.','Передать контекст специалисту; доплату согласовать отдельно.'] };
      }
      addEvent(deal,'Результат расчётов сопоставлен',`Обязательство: ${formatMoney(p.amountMinor,p.currency)}. Зачислено: ${formatMoney(receivedMinor,p.currency)}. Разница: ${formatMoney(differenceMinor,p.currency)}.`, 'Симулятор банка');
      break;
    }
    case 'escalate': {
      requireState('exception');
      const result = caseGateway.create(deal.exception!,deal.id);
      deal.exception!.ticket = result.ticket; deal.state = 'escalated';
      addEvent(deal,'Кейс передан в демо-очередь',`Собраны документы, платёж, сверка и история. ${result.ticket}. В банк ничего не отправлено.`, 'Клиент');
      break;
    }
    default: throw new DomainError('Неизвестное действие.');
  }
  deal.version++; deal.updatedAt = new Date().toISOString(); deal.appliedCommands.push(commandId);
  return deal;
}
