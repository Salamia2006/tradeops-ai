import { createDeal, applyAction } from './engine';
import type { Deal } from './types';

export function sampleDocuments(variant: 'normal' | 'mismatch' = 'normal', company = 'Shanghai Huaxin Manufacturing', amount = '380000') {
  const shared = `Контракт: CN-2026-041\nПолучатель: ${company}\nСумма: ${amount}\nВалюта: CNY\nСчёт: DEMO-CN-888800001234\nКод банка: DEMOCNSHXXX\nСтрана: Китай\nСрок оплаты: 2026-12-20\nНазначение: Оплата промышленного оборудования по контракту CN-2026-041\nКомиссии: SHA`;
  return { contract:`ДЕМОНСТРАЦИОННЫЙ КОНТРАКТ\nВсе организации и реквизиты вымышлены.\n${shared}`, invoice:`ДЕМОНСТРАЦИОННЫЙ ИНВОЙС\nИнвойс: INV-2026-087\n${variant === 'mismatch' ? shared.replace(`Сумма: ${amount}`,`Сумма: ${Number(amount)+2000}`) : shared}` };
}
export function seedDeals(): Deal[] {
  const firstDocs = sampleDocuments();
  let first = createDeal('Оплатить китайскому поставщику 380 000 CNY по этому контракту', firstDocs.contract,firstDocs.invoice);
  first = applyAction(first,{type:'analyze'},'seed-1');
  first = applyAction(first,{type:'approve',confirmed:true},'seed-2');
  first = applyAction(first,{type:'submit'},'seed-3');
  first = applyAction(first,{type:'reconcile',received:'378500',correspondentFee:'1500',senderFee:'250',currency:'CNY'},'seed-4');
  const secondDocs = sampleDocuments('normal','Shenzhen Horizon Electronics','125000');
  let second = createDeal('Оплатить поставщику 125000 CNY',secondDocs.contract,secondDocs.invoice);
  second = applyAction(second,{type:'analyze'},'seed-1');
  const thirdDocs = sampleDocuments('mismatch','Ningbo Ocean Components','96000');
  let third = createDeal('Оплатить поставщику 96000 CNY',thirdDocs.contract,thirdDocs.invoice);
  third = applyAction(third,{type:'analyze'},'seed-1');
  return [first,second,third];
}
