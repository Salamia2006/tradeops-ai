import type { Deal } from './types';

export const storageMode: 'server' | 'browser' = 'server';
export type ApiResponse = { deals: Deal[]; deal: Deal; error?: string };
export async function api(body?: unknown): Promise<ApiResponse> {
  const response = await fetch('/api/deals', body ? {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body)
  } : { cache: 'no-store' });
  const data = await response.json() as ApiResponse;
  if (!response.ok) throw new Error(data.error || 'Не удалось выполнить действие.');
  return data;
}
