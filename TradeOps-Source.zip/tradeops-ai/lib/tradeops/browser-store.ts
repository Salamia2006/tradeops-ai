import { z } from 'zod';
import { createDeal, applyAction, DomainError } from './engine';
import { seedDeals } from './fixtures';
import type { Deal } from './types';

const documents = { goal: z.string().min(1).max(1000), contract: z.string().max(30000), invoice: z.string().max(30000) };
const actionSchema = z.discriminatedUnion('type', [
  z.object({ type: z.literal('analyze') }), z.object({ type: z.literal('documents'), ...documents }),
  z.object({ type: z.literal('approve'), confirmed: z.boolean() }), z.object({ type: z.literal('submit') }),
  z.object({ type: z.literal('reconcile'), received: z.string().max(30), correspondentFee: z.string().max(30), senderFee: z.string().max(30), currency: z.string().length(3) }),
  z.object({ type: z.literal('escalate') })
]);
const commandSchema = z.discriminatedUnion('operation', [
  z.object({ operation: z.literal('create'), id: z.string().uuid(), ...documents }),
  z.object({ operation: z.literal('action'), id: z.string().uuid(), version: z.number().int().positive(), commandId: z.string().uuid(), action: actionSchema })
]);

export type BrowserWorkspace = { schema: 1; deals: Deal[] };
export function transitionWorkspace(saved: BrowserWorkspace | undefined, body?: unknown) {
  if (saved && (saved.schema !== 1 || !Array.isArray(saved.deals))) {
    throw new DomainError('Сохранённое демо имеет неподдерживаемый формат. Данные не изменены.');
  }
  const workspace: BrowserWorkspace = saved ? structuredClone(saved) : { schema: 1, deals: seedDeals() };
  let deal: Deal | undefined;
  if (body !== undefined) {
    const parsed = commandSchema.safeParse(body);
    if (!parsed.success) throw new DomainError('Некорректные поля команды. Проверьте введённые данные.');
    const command = parsed.data;
    const current = workspace.deals.find(d => d.id === command.id);
    if (command.operation === 'create') {
      deal = current || createDeal(command.goal, command.contract, command.invoice, command.id);
      if (!current) workspace.deals.push(deal);
    } else {
      if (!current) throw new DomainError('Сделка не найдена в этом браузере.');
      if (current.appliedCommands.includes(command.commandId)) deal = current;
      else {
        if (current.version !== command.version) throw new DomainError('Сделка уже изменена в другой вкладке. Обновите данные и повторите действие.');
        deal = applyAction(current, command.action, command.commandId);
        workspace.deals = workspace.deals.map(d => d.id === deal!.id ? deal! : d);
      }
    }
  }
  const deals = [...workspace.deals].sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
  return { workspace, response: { deals, deal: deal as Deal } };
}
