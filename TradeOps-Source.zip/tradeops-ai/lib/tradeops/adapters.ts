import type { PaymentDraft, ExceptionCase } from './types';

// These are our proposed integration contracts, NOT documented VTB APIs.
export interface PaymentGateway { submit(payment: PaymentDraft, idempotencyKey: string): { reference: string; simulated: boolean }; }
export interface CurrencyControlGateway { preflight(payment: PaymentDraft): { status: 'demo_only'; message: string }; }
export interface CaseGateway { create(exception: ExceptionCase, dealId: string): { ticket: string; simulated: boolean }; }

export const paymentGateway: PaymentGateway = {
  submit(_payment, key) { return { reference: `SIM-PAY-${key}`, simulated: true }; }
};
export const currencyControlGateway: CurrencyControlGateway = {
  preflight() { return { status: 'demo_only', message: 'Пакет для валютного контроля подготовлен. Проверка банка и регуляторных требований не выполнялась.' }; }
};
export const caseGateway: CaseGateway = {
  create(_exception, id) { return { ticket: `SIM-CASE-${id}`, simulated: true }; }
};
