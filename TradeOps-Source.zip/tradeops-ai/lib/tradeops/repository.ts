import { env } from 'cloudflare:workers';
import type { Deal } from './types';
import { seedDeals } from './fixtures';

function db() { if (!env.DB) throw new Error('Хранилище временно недоступно.'); return env.DB; }
export async function initialize(owner: string) {
  const existing = await db().prepare('SELECT owner FROM demo_sessions WHERE owner = ?').bind(owner).first();
  if (existing) return;
  const initial = seedDeals();
  // One atomic batch: a racing initializer rolls back on the unique session key.
  try {
    await db().batch([
      db().prepare('INSERT INTO demo_sessions (owner, created_at) VALUES (?, ?)').bind(owner,new Date().toISOString()),
      ...initial.map(d => db().prepare('INSERT INTO deals (owner,id,version,data,updated_at) VALUES (?,?,?,?,?)').bind(owner,d.id,d.version,JSON.stringify(d),d.updatedAt))
    ]);
  } catch (error) { if (!await db().prepare('SELECT owner FROM demo_sessions WHERE owner = ?').bind(owner).first()) throw error; }
}
export async function listDeals(owner: string): Promise<Deal[]> {
  const rows = await db().prepare('SELECT data FROM deals WHERE owner = ? ORDER BY updated_at DESC').bind(owner).all<{ data:string }>();
  return rows.results.map(row => JSON.parse(row.data));
}
export async function getDeal(owner: string, id: string): Promise<Deal | null> {
  const row = await db().prepare('SELECT data FROM deals WHERE owner = ? AND id = ?').bind(owner,id).first<{data:string}>();
  return row ? JSON.parse(row.data) : null;
}
export async function insertDeal(owner: string, d: Deal) {
  await db().prepare('INSERT INTO deals (owner,id,version,data,updated_at) VALUES (?,?,?,?,?)').bind(owner,d.id,d.version,JSON.stringify(d),d.updatedAt).run();
}
export async function saveDeal(owner: string, d: Deal, expected: number): Promise<boolean> {
  const result = await db().prepare('UPDATE deals SET version = ?, data = ?, updated_at = ? WHERE owner = ? AND id = ? AND version = ?').bind(d.version,JSON.stringify(d),d.updatedAt,owner,d.id,expected).run();
  return result.meta.changes === 1;
}
